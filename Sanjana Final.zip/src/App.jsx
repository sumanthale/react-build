import ROUTES from "./routes";

const App = () => {
  return (
    <>
      <ROUTES />
    </>
  );
};

export default App;
